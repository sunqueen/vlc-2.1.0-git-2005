/* Automatically generated */

#include "stdafx.h"
